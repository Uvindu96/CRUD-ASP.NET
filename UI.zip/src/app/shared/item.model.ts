export class Item {
     Price: number;
     ItemID : number;
     Name : string;
     
   
       
}
