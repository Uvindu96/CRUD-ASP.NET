import { Component, OnInit } from '@angular/core';
import { OrderService } from '../shared/order.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import {  ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styles: []
})
export class OrdersComponent implements OnInit {

  orderList;
  constructor(private service : OrderService,
    private route : Router,
    private toaster : ToastrService) { }

  ngOnInit() {

    this.refreshList();
   
  }
  refreshList(){
    this.service.getOrderlist().then(res => this.orderList = res);
  }

  openForEdit(orderID : number){

    this.route.navigate(['/order/edit/'+orderID]);
  }

  onOrderDelete(id : number){
    if(confirm('Are You Sure, You want to Delete This?')){
    this.service.deleteOrder(id).then(res =>{
      this.refreshList();
      this.toaster.warning("Deleted Successfully","Food-Mate");
    });
  }

  }

}
